/*
 * Filter.java 
 * 
 */

package studentRecordsBackup.util;

public interface Filter
{
	public boolean check(int x);

}
