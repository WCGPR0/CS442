/*
 * OddEvenFilterI.java
 *
 */

package studentRecordsBackup.util;

import studentRecordsBackup.util.Filter;

public class OddEvenFilterI implements Filter
{
	@Override
	public boolean check(int x) {
		return true;
	}
}

