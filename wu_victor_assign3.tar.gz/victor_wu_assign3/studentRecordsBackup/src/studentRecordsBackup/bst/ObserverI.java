/*
 * ObserverI.java
 */
package studentRecordsBackup.bst;

import java.util.Observer;

public interface ObserverI extends Observer{
	
}

